  <?php

    // importeer
    include_once 'Database.php';

    if (isset($_POST['submit']) && $_SERVER['REQUEST_METHOD'] == 'POST') {
        $sql = "INSERT INTO artikel VALUES (:code, :naam, :achternaam, :email)";

        //associative array
        $placeholders = [
            'code' => NULL,
            'naam' => $_POST['naam'],
            'achternaam' => $_POST['achternaam'],
            'email' => $_POST['email']
        ];

        $db = new database();
        $db->insert($sql, $placeholders, 'beheer-medewerker.php');
    }
    ?>


  <form class="form" action="nieuw_medewerker.php" method="post">
      <input type="text" name="naam" placeholder="<?php echo isset($naam) ? $naam : 'naam' ?>">
      <input type="text" name="achternaam" placeholder="<?php echo isset($achternaam) ? $achternaam : 'achternaam' ?>">
      <input type="text" name="personeelscode" placeholder="<?php echo isset($personeelscode) ? $personeelscode : 'personeelscode' ?>">
      <input type="text" name="email" placeholder="<?php echo isset($email) ? $email : 'email' ?>">
      <input type="submit" name="submit" value="join the club!">
  </form>

  </body>
  <style>
      #html {
          background: linear-gradient(95deg, #5533ff 40%, #25ddf5 100%);
      }

      .form {
          position: absolute;
          bottom: 20px;
          left: 20%;
          background-color: white;
          border-radius: 10px;
          padding: 10px;
      }
  </style>