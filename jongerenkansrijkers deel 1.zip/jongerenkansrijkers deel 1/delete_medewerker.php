<?php

// GET want we willen data uit onze url opnemen/gebruiken
// artikel_id want deze wordt in overzicht_artikelen.php meegegeven aan de url
 
// check of de super global get een key artikel_id bevat en deze dus een value heeft
if(isset($_GET['personeels_id'])){

    // een sql string maken die een delete statement gebruikt voor een bepaalde id
    // artikel_id is een named placeholder
    $sql = "DELETE FROM personeel WHERE personeelscode=:personeels_id";

    // maak gebruik van named placeholders voor doorvoeren van artikel_id
    // dus: key in associative array moet hetzelfde zijn als de named placeholder op regel 18 (artike_id)
    $placeholders = ['personeels_id' => $_GET['personeels_id']];

    // maak in je database class een generieke functie die de delete statement uitvoert
    // importeer
    include_once 'Database.php';

    // maak een db instance
    $db =  new database();

    $db->delete($sql, $placeholders, 'beheer-medewerker.php');


}else{

}


